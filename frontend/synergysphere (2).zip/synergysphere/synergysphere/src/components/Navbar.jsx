import { Link } from 'react-router-dom';
import '../styles/Navbar.css';

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-left">
        <h1>Title of the Project</h1>
      </div>
      <div className="navbar-right">
        <Link to="/">Home</Link>
        <Link to="#">Solutions</Link>
        <Link to="#">Work</Link>
        <Link to="#">About</Link>
        <Link to="/login">Login</Link>
        <Link to="/signup">Sign UP</Link>
      </div>
    </nav>
  );
}
