import '../styles/Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-section">[Company Banner]</div>
      <div className="footer-section">
        <h4>Quick Links</h4>
        <p>Link 1</p>
        <p>Link 2</p>
      </div>
      <div className="footer-section">
        <h4>Company</h4>
        <p>About</p>
        <p>Careers</p>
      </div>
      <div className="footer-section">
        <h4>Connect with us</h4>
        <p>Instagram</p>
        <p>LinkedIn</p>
      </div>
    </footer>
  );
}
