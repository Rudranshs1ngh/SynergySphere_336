import '../styles/ProjectCard.css';

export default function ProjectCard({ project }) {
 const taskOpenFunction = () => {
    window.location.href = '/task';
}

  return (
    <div className="project-card" onClick={taskOpenFunction}>
      <img src={project.image} alt="project" className="project-image" />
      <h3>{project.name}</h3>
      <p>{project.status}</p>
      <p>Due: {project.deadline}</p>
      <p>Tasks: {project.tasks.length}</p>
    </div>
  );
}