import '../styles/Login.css';
import { Link } from 'react-router-dom';

export default function Login() {
  return (
    <div className="auth-container">
      <h2>Login into account</h2>
      <form className="auth-form">
        <input type="email" className="input" placeholder="Email" />
        <input type="password" className="input" placeholder="Password" />
        <p style={{ textAlign: 'right' }}>
          <Link to="/forgot-password" style={{ color: 'red' }}>Forgot password?</Link>
        </p>
        <button className="button">Login</button>
        <p>Don't have an account? <Link to="/signup">Signup instead</Link></p>
      </form>
    </div>
  );
}
