import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ProjectCard from '../components/ProjectCard';
import '../styles/Dashboard.css';

const sampleProjects = [
  {
    name: "Cultured Cobra",
    status: "In Progress",
    deadline: "2025-06-30",
    tasks: [1, 2, 3],
    image: "/assets/project1.png",
  },
  {
    name: "Visionary Vulture",
    status: "Completed",
    deadline: "2025-05-01",
    tasks: [1],
    image: "/assets/project2.png",
  }
];

export default function Dashboard() {
  const newProject = () =>{
   window.location.href = '/createProject';
  }
  return (
    <>
      <Navbar />
      <div className="dashboard">
        <aside className="sidebar">
          <p>Projects</p>
          <p>My Tasks</p>
        </aside>
        <main className="project-container">
          <div className="header-bar">
            <input type="text" placeholder="Search..." />
            <button onClick={newProject}>+ New Project</button>
          </div>
          <div className="project-grid">
            {sampleProjects.map((project, idx) => (
              <ProjectCard key={idx} project={project} />
            ))}
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}
