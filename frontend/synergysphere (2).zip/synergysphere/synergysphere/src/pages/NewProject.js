export default function NewProject({ project }) {


  return (
    <div className="project-card">
      this is the new PROJECT PAGE.
    </div>
  );
}