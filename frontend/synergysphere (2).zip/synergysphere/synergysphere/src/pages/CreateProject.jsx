import '../styles/CreateProject.css';

export default function CreateProject() {
  return (
    <div className="form-container">
      <h2>Create New Project</h2>
      <form>
        <input type="text" placeholder="Name" />
        <input type="text" placeholder="Tags" />
        <input type="text" placeholder="Project Manager" />
        <input type="date" />
        <div className="priority">
          <label><input type="radio" name="priority" value="low" /> Low</label>
          <label><input type="radio" name="priority" value="medium" /> Medium</label>
          <label><input type="radio" name="priority" value="high" /> High</label>
        </div>
        <input type="file" />
        <textarea placeholder="Description"></textarea>
        <button type="submit">Save</button>
      </form>
    </div>
  );
}
