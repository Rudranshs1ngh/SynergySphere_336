import '../styles/Signup.css';
import { Link } from 'react-router-dom';

export default function Signup() {
  return (
    <div className="auth-container">
      <h2>Create an account</h2>
      <form className="auth-form">
        <input className="input" type="text" placeholder="First name" />
        <input className="input" type="text" placeholder="Last name" />
        <input className="input" type="email" placeholder="Email" />
        <input className="input" type="password" placeholder="Password" />
        <label>
          <input type="checkbox" /> I agree to the Terms and Privacy Policy
        </label>
        <button className="button">Create an account</button>
        <p>Already have an account? <Link to="/">Log in instead</Link></p>
      </form>
    </div>
  );
}