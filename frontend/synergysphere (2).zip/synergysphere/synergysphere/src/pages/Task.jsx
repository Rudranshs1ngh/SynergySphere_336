

export default function Task({ project }) {


  return (
    <div className="project-card">
      this is the taskPage.
    </div>
  );
}